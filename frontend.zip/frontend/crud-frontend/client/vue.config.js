module.exports = {
  runtimeCompiler: true
};
